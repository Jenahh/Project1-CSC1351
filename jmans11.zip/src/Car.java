
/**
 * <Car.java>
 * This class allows users to create instances of cars and retrieve their
 * attributes through the methods. It creates a means to work with car data for
 * the project.
 *
 * CSC 1351 Programming Project No <1>
 *
 * Section <2>
 *
 * @author <Jenah Mansour>
 * @since <March 17, 2024>
 *
 */
public class Car implements Comparable<Car> {

    private String make; //Represents the make/brand of the car.
    private int year; //Represents the year the car was made.
    private int price; //Represents the price of the car.

    /**
     * <Car()>
     * This method is the constructor of the class and initializes a new car
     * with the specified parameters and sets the member variables equal to
     * those parameter values.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param Make: This parameter equals the make of the car and is used to set
     * the member variable equal to this value.
     * @param Year: This parameter equals the year of the car and is used to set
     * the member variable equal to this value.
     * @param Price: This parameter equals the price of the car and is used to
     * set the member variable equal to this value.
     * @since <March 17,2024>
     *
     */
    public Car(String Make, int Year, int Price) {
        this.make = Make;
        this.year = Year;
        this.price = Price;
    }

    /**
     * <getMake()>
     * This method returns the value of the member variable make.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @return Returns the member variable make so that it can be accessed
     * outside of the class.
     * @since <March 17, 2024>
     *
     */
    public String getMake() {
        return make;
    }

    /**
     * <getYear()>
     * This method returns the year the car was made through the member variable
     * year.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @return Returns the member variable year so that it can be accessed
     * outside of the class.
     * @since <March 17, 2024>
     *
     */
    public int getYear() {
        return year;
    }

    /**
     * <getPrice()>
     * This method returns the price of the car through the member variable
     * price.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @return Returns the member variable year so that it can be accessed
     * outside of the class.
     * @since <March 17, 2024>
     *
     */
    public int getPrice() {
        return price;
    }

    /**
     * <compareTo()>
     * This method implements the compareTo method for the Comparable interface.
     * It lays out the structure of the Car objects by sorting them based on the
     * make and year attributes. The comparison is first based on the make and
     * then if the makes of 2 cars are equal it compares the year.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param other: This parameter is a car object that is used to make the
     * comparison that allows the method to sort the cars correctly.
     * @since <March 17, 2024>
     *
     */
    @Override
    public int compareTo(Car other) {
        if (this.make.compareTo(other.make) == 0) {
            return Integer.compare(year, other.year);
        } else {
            return this.make.compareTo(other.make);
        }
    }

    /**
     * <toString()>
     * This method returns a string version of the car object in the format
     * shown below.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @since <March 17, 2023>
     *
     */
    @Override
    public String toString() {
        return "Make: " + make + ", Year : " + year + ", Price: $" + price;
    }
}
