
/**
 * <Prog01_aOrderedList.java>
 * This class acts as the main program in this project. It contains 2 methods
 * (GetInputFile and GetOutputFile) that establish a connection between the
 * input file that a user specifies and an output file that they specify, thus
 * handling the input and output of this project. It manages an ordered list of
 * cars by utilizing the 2 other classes that we have, aOrderedList.java and
 * Car.java.
 *
 * CSC 1351 Programming Project No <1>
 *
 * Section <2>
 *
 * @author <Jenah Mansour>
 * @since <March 17, 2024>
 *
 */
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.*;

public class Prog01_aOrderedList {

    /**
     * <GetInputFile()>
     * This method returns a Scanner object that is ready to read input from a
     * text file. It prompts the user to enter an input file and assesses
     * whether that file exists or not. If the file does exist then the code
     * returns a Scanner object. If the file does not exist, then the program
     * prompts the user to continue or cancel the program by entering Y or N
     * respectively. If the user enters Y, the program re-prompts the user for
     * the file name and loops until the user enters a file name that exists. If
     * the user enter N then a FileNotFoundException is thrown.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param UserPrompt: Asks the user to enter the name of their input file
     * @return Scanner object that is ready to read input from a text file
     * @throws java.io.FileNotFoundException if user enters that they would like
     * to cancel the program's execution
     * @since <March 17, 2024>
     *
     */
    @SuppressWarnings("resource")
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
        Scanner scan = new Scanner(System.in); //Creates a scanner that is used to read input from the user for the file name or loop until the file name entered is correct or cancels the execution. 
        File inputFile; //Creates a File object where the value is later set to the file name that is inputed by the user.
        String fileName; //Variable that takes in the input from the scanner for the file name and is used to create a new file object by this name.

        do {
            System.out.print(UserPrompt);
            fileName = scan.nextLine();
            inputFile = new File(fileName);
            if (!inputFile.exists()) {
                System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N>");
                String response = scan.nextLine(); //Creates a variable that takes in the response value of the user in order to see whether the user would like to continue or end code execution.
                if (response.equalsIgnoreCase("N")) {
                	scan.close();
                    throw new FileNotFoundException("User canceled program execution");
                } else if(response.equalsIgnoreCase("Y")){
                	continue;
                } else{
                    System.out.println("Please enter <Y/N>");
                    continue;
                }
            }
        } while (!inputFile.exists());

        return new Scanner(inputFile);

    }

    /**
     * <GetOutputFile()>
     * This method returns a PrintWriter object that is ready to write output
     * into a text file. It prompts the user to enter an output file. Then it
     * reads the file name and checks if the file exists. If the file does exist
     * then the code returns a Scanner object. If the file does not exist, then
     * the program prompts the user to continue or cancel the program by
     * entering Y or N respectively. If the user enters Y, the program
     * re-prompts the user for the file name and loops until the user enters a
     * file name that exists.If the user enter N then a FileNotFoundException is
     * thrown.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param UserPrompt
     * @return PrintWriter object that is ready to write output into the output
     * file
     * @throws java.io.FileNotFoundException
     * @since <March 17, 2024>
     *
     */
    public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
        Scanner scan = new Scanner(System.in); //Creates a scanner that is used to read input from the user for the file name or loop until the file name entered is correct or cancels the execution.
        File outFile;//Creates a File object where the value is later set to the file name that is inputed by the user.
        String fileName;//Variable that takes in the input from the scanner for the file name and is used to create a new file object by this name.
        String response;//Creates a variable that takes in the response value of the user in order to see whether the user would like to continue or end code execution.

        System.out.print(UserPrompt);
        fileName = scan.next();

        outFile = new File(fileName);

        if (!outFile.exists()) {
            System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N>");
            while (scan.hasNext()) {
                response = scan.next();
                switch (response) {
                    case "Y":
                        GetOutputFile(UserPrompt);
                        break;
                    case "N":
                        throw new FileNotFoundException("User canceled program.");
                    default:
                        System.out.println("Please enter <Y/N>");
                }
            }
        }
        scan.close();
        return new PrintWriter(outFile);
    }

    /**
     * <main()>
     * This method is the main method which serves as the entry point for the
     * program. It first initializes a Scanner object and calls the GetInputFile
     * method in order to prompt the user to enter a file name. That method then
     * returns a Scanner object that reads input from that file. Next, the main
     * method creates an instance of the aOrderedList class which represents a
     * list of cars. It then loops to read each line of input from the input
     * file till the end. Then it splits each line into an array of strings so
     * that it can decipher whether the input file has an A pr D prefix
     * signifying whether to add or delete a car from the list. Then the program
     * initializes a PrintWriter object and calls the GetOutputFile method where
     * it obtains the output file from the user. Then the program prints the
     * ordered list into the output file using the specified format.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @throws java.io.FileNotFoundException if input or output files cannot be
     * found
     * @since <March 17, 2024>
     *
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner inputFile = GetInputFile("Enter input filename: "); //Initializes scanner object in order to call the GetInputFile method with a prompt asking the user to enter the file name as its parameters.
        aOrderedList list = new aOrderedList(); //Creates an instance of the aOrderedList class which will be used to either add or remove cars from.

        while (inputFile.hasNextLine()) {
            String[] carData = inputFile.nextLine().split(","); //Creates a String array in order to use the split function on each line of input in the inputfile in order to separate the car information obtained.

            if (carData.length == 4 && carData[0].equals("A")) {
                String make = carData[1];
                int year = Integer.parseInt(carData[2]); //The given input is now a string because of the array so we have to parseInt in order to set the year equal to the index of the String array that equals the information.
                int price = Integer.parseInt(carData[3]); //The given input is now a string because of the array so we have to parseInt in order to set the year equal to the index of the String array that equals the information.
                Car newCar = new Car(make, year, price); //Creates car object with the data given by the input file and then later adds it to the aOrderedList object list.
                list.add(newCar);

            } else if (carData[0].equals("D") && carData.length == 3) {
                String make = carData[1];
                int year = Integer.parseInt(carData[2]); //The given input is now a string because of the array so we have to parseInt in order to set the year equal to the index of the String array that equals the information.
                Car carToDelete = new Car(make, year, 0); //Creates a dummy car object with the specifications that the input file is looking to delete. The price of the car does not matter in this case.
                boolean carFound = false; //Initializes a boolean of whether a car that matches the description given by the inputfile has been found to false. This will be used to track whether a car is found later on.
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).compareTo(carToDelete) == 0) {
                        list.remove(i);
                        carFound = true;
                        break; // Exit loop once car is deleted.
                    }
                }
                if (!carFound) {
                    System.out.println("Car to delete not found: " + make + ", " + year);
                }
            }
        }
        inputFile.close();

        PrintWriter getOutputFile = GetOutputFile("Enter output filename: ");
        getOutputFile.printf("%s\t%10s\n", "Number of cars ", list.size());
        getOutputFile.println();
        list.reset();

        while (list.hasNext()) {
            Comparable<?> carObj = list.next(); //Comparable object is set equal to the next value in the list.
            try {
                Car car = (Car) carObj; //Casts the Comparable object to car so that we can create a Car object and then use it to print out the information into the output file.
                getOutputFile.printf("Make:\t%10s\n", car.getMake());
                getOutputFile.printf("Year:\t%10d\n", car.getYear());
                String combinePrice = String.format("$%,d", car.getPrice());
                getOutputFile.printf("Price:\t%10s\n", combinePrice);
                getOutputFile.println(); // Add a blank line between cars.
            } catch (Exception e) {
                System.err.println();
            }
        }
        getOutputFile.close();
    }
}
