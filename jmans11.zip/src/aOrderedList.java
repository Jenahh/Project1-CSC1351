
/**
 * <aOrderedList.java>
 * This class designs a custom ordered list that stores Car objects from the Car
 * Class in a sorted order. It provides methods that help gain information about
 * an ordered list of objects and manage them.
 *
 * CSC 1351 Programming Project No <1>
 *
 * Section <2>
 *
 * @author <Jenah Mansour>
 * @since <March 17, 2024>
 *
 */
import java.util.Arrays;

public class aOrderedList {

    final int SIZEINCREMENTS = 20; //Represents the size of the increments for increasing a list. 
    private Comparable<Car>[] oList; //An array of Comparable objects that stands for the ordered list and it is used in the methods below to access information about the list.
    private int listSize; //Represents the current size of the ordered list.
    private int numObjects; //Signifies the number of objects in the ordered list.
    private int curr; //Index variable used for the iterator methods that we created

    /**
     * <aOrderedList()>
     * This method is the constructor of the class and initializes the ordered
     * list by setting numObjects = 0, listSize = SIZEINCREMENTS, and
     * instantiates the array oList to a size of SIZEINCREMENTS. This method
     * allows us to create objects by calling the constructor.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @since <March 17, 2024>
     *
     */
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[SIZEINCREMENTS];
    }

    /**
     * <add()>
     * This method adds a new object to the sorted array at the correct index
     * and maintains the sorted order of the array.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param newObject: A parameter with type Comparable that is used to
     * specify the object that should be added to the list.
     * @since <March 17, 2024>
     *
     */
    public void add(Comparable<Car> newObject) {
        int index = 0; //Initializes index variable to 0 so that it can be used to set the correct index in the list equal to the object given in the parameter.
        if (numObjects == listSize) {
            listSize += SIZEINCREMENTS;
            oList = Arrays.copyOf(oList, listSize);
        }
        
        while (index < numObjects && newObject.compareTo((Car) oList[index]) > 0) {
            index++;
        }
        
        for (int i = numObjects - 1; i >= index; i--) {
            oList[i + 1] = oList[i];
        }
        
        oList[index] = newObject;
        numObjects++;
    }

    /**
     * <toString()>
     * This method returns a string version of the list objects and chains the
     * string representations of each object in the list while separating them
     * by commas and enclosing them by brackets.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @since <March 17, 2024>
     *
     */
    @Override
    public String toString() {
        String toString = "["; //Initializes the variable to equal the first value necessary for this method and then has objects at all indexes less than the number of objects added to the string and is finished off by the final bracket.
        for (int i = 0; i < numObjects; i++) {
            toString += oList[i].toString();
            if (i < numObjects - 1) {
                toString += ", ";
            }
        }
        toString += "]";
        return toString;
    }

    /**
     * <size()>
     * This method returns the number of elements that are currently in the list
     * given by the variable numObjects. 
     * 
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     *
     * @author <Jenah Mansour>
     * @return The number of objects in the list.
     * @since <March 17, 2024>
     *
     */
    public int size() {
        return numObjects;
    }

    /**
     * <get()>
     * This method returns the element at the specified index in the list. It
     * allows the program to access each individual element of a list by using
     * their index.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param index: Takes in the index of the element that we are looking for.
     * @return The element at the specified index.
     * @since <March 17, 2024>
     *
     */
    public Comparable<Car> get(int index) {
        while (index >= 0 || index < numObjects) {
            return oList[index];
        }
        System.out.println("Index is out of bounds.");
        return null;
    }

    /**
     * <isEmpty()>
     * Checks whether the list is empty and returns a true or false value.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @return Returns true if the list is empty and returns false if not.
     * @since <March 17, 2024>
     *
     */
    public boolean isEmpty() {
        return oList.length == 0;
    }

    /**
     * <remove()>
     * This method takes in the index of the list as a parameter and then
     * removes the element from the list. Then it adjusts the list so that the
     * elements that come after the removed element are shifter down so that
     * there is not a gap in the middle of the array. This ensures that the list
     * stays ordered.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @param index: Takes in index so that the method can know what element
     * should be removed from the list.
     * @since <March 17, 2024>
     *
     */
    public void remove(int index) {
        if (index < 0 || index >= numObjects) {
            throw new IndexOutOfBoundsException("Index out of bounds");
        }

        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        numObjects--;
    }

    /**
     * <reset()>
     * This method is used to reset the iterator parameters so that the next
     * element becomes the first element in the list. It allows the iterator to
     * go through the list again from the beginning. This method is not
     * currently used as we do not have an iterator present in the program for
     * this project.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @since <March 17, 2024>
     *
     */
    public void reset() {
        curr = 0;
    }

    /**
     * <next()>
     * This method is used to return the next element in the list. It returns
     * the element at the current position of the iterator and moves the
     * iterator to the next position. This method is not currently used as we do
     * not have an iterator present in the program for this project.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @return Returns the elements in the collection until all the elements
     * have been covered. Once there are no more elements, the method returns
     * null.
     * @since <March 17, 2024>
     *
     */
    public Comparable<Car> next() {
        while (hasNext()) {
            return oList[curr++];
        }
        return null;
    }

    /**
     * <hasNext()>
     * This method checks to make sure that there are more elements to be
     * traversed in a list. It returns true if there are more elements remaining
     * and false if not.This method is not currently used as we do not have an
     * iterator present in the program for this project.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @return Returns true if there are more elements left in a list and false
     * if not.
     * @since <March 17, 2024>
     *
     */
    public boolean hasNext() {
        return curr < numObjects;
    }

    /**
     * <remove()>
     * This method is used to remove the last element that the next() method
     * returned from the list. It deletes the element at the current position of
     * the iterator from the list.
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Jenah Mansour>
     * @since <March 17, 2024>
     *
     */
    public void remove() {
        if (curr > 0) {
            throw new IllegalStateException();
        }
        remove(curr - 1);
        curr--;
    }
}
